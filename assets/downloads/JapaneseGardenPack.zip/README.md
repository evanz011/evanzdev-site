# Low-Poly Japanese Garden Asset Pack

16 assets, faceted low-poly. **73,498 triangles across 252 mesh parts.** Heaviest single
part is 8,528 — under Roblox's 10,000-per-mesh limit, which is the number that gates import.

![sheet](asset_sheet.png)

## Roblox Studio — read this first

**Colour.** Roblox's importer does *not* read material colours from FBX/OBJ; it only reads
textures. Flat-coloured materials always arrive grey. So every colour in this pack is baked
into `JapanPack_Atlas.png` (a 512px grid of flat swatches) and each face is UV-mapped onto
its swatch. The texture is **embedded in every FBX**, so:

> Import with **"Import textures" ON**. The colours arrive automatically. Nothing to set by hand.

**Invisible walls.** These are collision hulls, not geometry. A convex hull around a torii
gate is a solid slab that fills the gateway — you can't walk through your own gate. So the
architectural assets are **pre-split into convex chunks**: the torii ships as 26 separate
pillar/beam/wedge meshes rather than one, the bridge as 114. Each chunk's hull matches what
you see, so the default fidelity behaves.

After import:

| Asset | CollisionFidelity | CanCollide |
| --- | --- | --- |
| Torii, bridge, pagoda, lantern, hokora, fence, chōchin, tsukubai | `Box` (they're chunks now) | true |
| Boulder, stepping stone, zen garden | `Box` | true |
| Waterfall cliff | `Hull` | true |
| Waterfall water / foam / mist | any | **false** |
| Tree canopies, grass tufts, bamboo leaves | any | **false** |

**Merge Meshes must be OFF.** Bridge, maple and bamboo grove exceed 10k triangles in total
but not per-part; merging collapses them into one mesh and the import fails.

**Scale** is baked at 1 stud = 0.28 m. An R15 character is ~5.5 studs, so the torii (18.7
studs) is something you walk under and the stone lantern (8.6) is about head height.

## Contents

| Asset | Parts | Tris | Max part | Size (studs, W×D×H) |
| --- | --- | --- | --- | --- |
| Torii Gate | 26 | 3,096 | 220 | 25.2 × 2.8 × 18.7 |
| Arched Bridge | 114 | 11,584 | 108 | 28.9 × 7.8 × 10.8 |
| Pagoda | 17 | 2,496 | 320 | 8.6 × 8.6 × 17.4 |
| Stone Lantern | 17 | 2,606 | 320 | 3.8 × 4.3 × 8.6 |
| Hokora Shrine | 13 | 1,516 | 164 | 5.6 × 5.2 × 7.0 |
| Waterfall | 5 | 9,616 | 5,220 | 27.3 × 25.7 × 22.5 |
| Tsukubai Basin | 8 | 1,144 | 220 | 6.7 × 7.0 × 3.1 |
| Bamboo Fence | 27 | 4,428 | 164 | 21.8 × 0.6 × 4.8 |
| Chōchin Lantern | 7 | 972 | 220 | 3.3 × 1.9 × 9.3 |
| Zen Sand Garden | 6 | 1,220 | 432 | 15.4 × 12.5 × 2.9 |
| Sakura Tree | 3 | 9,396 | 4,424 | 22.2 × 16.0 × 28.8 |
| Maple Tree | 3 | 10,348 | 5,580 | 15.3 × 20.6 × 26.7 |
| Bamboo Grove | 3 | 12,804 | 8,528 | 11.0 × 11.4 × 24.6 |
| Grass Tufts | 1 | 1,912 | 1,912 | 14.6 × 13.0 × 1.8 |
| Boulder | 1 | 168 | 168 | 5.6 × 5.4 × 4.8 |
| Stepping Stone | 1 | 192 | 192 | 2.9 × 2.8 × 0.7 |

## Files

- `fbx_roblox/` — **one FBX per asset**, Roblox-scaled, colour atlas embedded, split into
  convex collision chunks. This is the set to import into Studio.
- `JapanPack_Atlas.png` — the colour atlas (already embedded in the FBXs; here for reference).
- `fbx/` — one FBX per asset in metres with real materials, for Blender / Unity / Godot,
  where engines *do* read material colours and none of the above applies.
- `JapanPack.blend` — library scene, every asset in its own collection.
- `garden_scene.blend` / `garden_hero.png` — a garden built only from pack assets.
- `jp_lib.py`, `jp_assets.py` — the builders. Everything is **procedural and seeded**.

## Regenerating / varying assets

Nothing is hand-modelled. Every builder takes an origin, a `scale` and (where it matters) a
`seed`:

```python
sakura((0, 0, 0), scale=1.4, seed=99)     # a different cherry tree
rock((3, 1, 0), size=2.2, seed=7)          # a different boulder
bamboo((0, 0, 0), count=14, seed=3)        # a denser grove
```

## Cut from the pack

Koi pond, cloud pine (niwaki) and shishi-odoshi were removed. Builders remain in
`jp_assets.py` (`pond()`, `lily_pads()`, `koi()`, `pine()`, `shishi_odoshi()`).

## Palette

One flat colour per material — recolouring the pack is a one-line edit in `jp_lib.HEX`,
then re-run the export to rebuild the atlas.
